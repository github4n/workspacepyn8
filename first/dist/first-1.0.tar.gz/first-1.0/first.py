

def print_fun():
    print("function")