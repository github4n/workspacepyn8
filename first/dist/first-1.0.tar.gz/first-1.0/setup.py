from distutils.core import setup

setup(
    name="first",
    version="1.0",
    py_modules=['first'],
    url="www",
    author="leo",
    author_email="3@qq.com"
)